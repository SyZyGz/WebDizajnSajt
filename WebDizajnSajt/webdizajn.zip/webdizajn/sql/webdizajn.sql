-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 24, 2024 at 02:55 PM
-- Server version: 5.7.39
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdizajn`
--

-- --------------------------------------------------------

--
-- Table structure for table `Klijenti`
--

CREATE TABLE `Klijenti` (
  `KlijentID` int(11) NOT NULL,
  `Ime` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Telefon` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Klijenti`
--

INSERT INTO `Klijenti` (`KlijentID`, `Ime`, `Email`, `Telefon`) VALUES
(1, 'Marko Marković', 'marko@example.com', '0612345678'),
(2, 'Jelena Janković', 'jelena@example.com', '0623456789');

-- --------------------------------------------------------

--
-- Table structure for table `Korisnici`
--

CREATE TABLE `Korisnici` (
  `id` int(11) NOT NULL,
  `korisnicko_ime` varchar(50) NOT NULL,
  `lozinka` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `datum_registracije` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Korisnici`
--

INSERT INTO `Korisnici` (`id`, `korisnicko_ime`, `lozinka`, `email`, `datum_registracije`) VALUES
(1, 'lazar', '$2y$10$TOU46DpPHynteSuKGd/9kOj9zZlAn03zN0v3nq7czXKx.cqd1XAxW', 'asd@asd', '2024-05-23 19:08:36');

-- --------------------------------------------------------

--
-- Table structure for table `Projekti`
--

CREATE TABLE `Projekti` (
  `ProjekatID` int(11) NOT NULL,
  `Naziv` varchar(100) NOT NULL,
  `Opis` text,
  `KlijentID` int(11) DEFAULT NULL,
  `TimID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Projekti`
--

INSERT INTO `Projekti` (`ProjekatID`, `Naziv`, `Opis`, `KlijentID`, `TimID`) VALUES
(1, 'Web aplikacija', 'Razvoj nove web aplikacije za klijenta.', 1, 1),
(2, 'Marketinška kampanja', 'Kampanja za novi proizvod.', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Resursi`
--

CREATE TABLE `Resursi` (
  `ResursID` int(11) NOT NULL,
  `Naziv` varchar(100) NOT NULL,
  `Tip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Resursi`
--

INSERT INTO `Resursi` (`ResursID`, `Naziv`, `Tip`) VALUES
(1, 'Laptop', 'Oprema'),
(2, 'Projektor', 'Oprema');

-- --------------------------------------------------------

--
-- Table structure for table `Timovi`
--

CREATE TABLE `Timovi` (
  `TimID` int(11) NOT NULL,
  `Naziv` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Timovi`
--

INSERT INTO `Timovi` (`TimID`, `Naziv`) VALUES
(1, 'Razvojni tim'),
(2, 'Marketing tim');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Klijenti`
--
ALTER TABLE `Klijenti`
  ADD PRIMARY KEY (`KlijentID`);

--
-- Indexes for table `Korisnici`
--
ALTER TABLE `Korisnici`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `Projekti`
--
ALTER TABLE `Projekti`
  ADD PRIMARY KEY (`ProjekatID`),
  ADD KEY `KlijentID` (`KlijentID`),
  ADD KEY `TimID` (`TimID`);

--
-- Indexes for table `Resursi`
--
ALTER TABLE `Resursi`
  ADD PRIMARY KEY (`ResursID`);

--
-- Indexes for table `Timovi`
--
ALTER TABLE `Timovi`
  ADD PRIMARY KEY (`TimID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Klijenti`
--
ALTER TABLE `Klijenti`
  MODIFY `KlijentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Korisnici`
--
ALTER TABLE `Korisnici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Projekti`
--
ALTER TABLE `Projekti`
  MODIFY `ProjekatID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Resursi`
--
ALTER TABLE `Resursi`
  MODIFY `ResursID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Timovi`
--
ALTER TABLE `Timovi`
  MODIFY `TimID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Projekti`
--
ALTER TABLE `Projekti`
  ADD CONSTRAINT `projekti_ibfk_1` FOREIGN KEY (`KlijentID`) REFERENCES `Klijenti` (`KlijentID`),
  ADD CONSTRAINT `projekti_ibfk_2` FOREIGN KEY (`TimID`) REFERENCES `Timovi` (`TimID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
