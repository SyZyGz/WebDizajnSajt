<?php
include 'config.php'; // Uključivanje konfiguracije za bazu podataka

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Provera korisnika u bazi
    $sql = "SELECT lozinka FROM Korisnici WHERE korisnicko_ime='$username'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['lozinka'])) {
            session_start();
            $_SESSION['username'] = $username;
            header("Location: pocetna.php");
            exit;
        } else {
            echo "Pogrešna lozinka!";
        }
    } else {
        echo "Korisničko ime ne postoji!";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('slike/poz2.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.8); /* Add opacity to make text readable */
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            margin-bottom: 20px;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            color: #555;
        }
        input {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            padding: 10px;
            background-color: #007BFF;
            border: none;
            border-radius: 4px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            margin-bottom: 10px;
        }
        button a {
            color: #fff;
            text-decoration: none;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Login</h1>
        <form method="post">
            <label for="username">Korisničko ime:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Lozinka:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Uloguj se</button>
            <button type="button" class="btn btn-secondary" onclick="window.location.href='register.php'">Registruj se</button>
        </form>
    </div>
</body>
</html>
