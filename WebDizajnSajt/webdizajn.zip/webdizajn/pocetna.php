<?php
include 'config.php'; // Uključivanje konfiguracije za bazu podataka
session_start();

// Funkcija za dobijanje podataka iz baze
function getData($conn, $table) {
    $sql = "SELECT * FROM $table";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Dobijanje podataka iz tabela
$klijenti = getData($conn, 'Klijenti');
$timovi = getData($conn, 'Timovi');
$resursi = getData($conn, 'Resursi');
$projekti = getData($conn, 'Projekti');
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Početna strana</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
   
        .card-header {
            background-color: #007bff;
            color: white;
        }
        .card {
            margin-bottom: 30px;
        }
        footer {
            background-color: #343a40;
            color: white;
        }
        footer p {
            margin: 0;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-primary, .btn-outline-light {
            width: 100%;
        }
        body, html {
            height: 100%;
        }
        .bg-image {
            background-image: url('slike/poz1.jpg');
            background-size: cover;
            background-position: center;
            height: 100%;
        }
        .centered {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        .footer {
            position: center;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Projekat</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Početna</a>
                    </li>
                </ul>
                <form class="d-flex" action="logout.php" method="post">
                    <button class="btn btn-outline-light" type="submit">Logout</button>
                </form>
            </div>
        </div>
    </nav>
    <div class="bg-image">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 class="text-white mt-5 mb-3">Dobrodošli na našu stranicu!</h1>
                    <!-- Other content goes here -->
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <h1 class="mb-5 text-center">Dobrodošli na našu stranicu!</h1>

        <!-- Prikaz tabela -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        Klijenti
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="table-primary">
                                <tr>
                                    <th>ID</th>
                                    <th>Ime</th>
                                    <th>Email</th>
                                    <th>Telefon</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($klijenti as $klijent): ?>
                                <tr>
                                    <td><?= $klijent['KlijentID'] ?></td>
                                    <td><?= $klijent['Ime'] ?></td>
                                    <td><?= $klijent['Email'] ?></td>
                                    <td><?= $klijent['Telefon'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        Timovi
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="table-primary">
                                <tr>
                                    <th>ID</th>
                                    <th>Naziv</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($timovi as $tim): ?>
                                <tr>
                                    <td><?= $tim['TimID'] ?></td>
                                    <td><?= $tim['Naziv'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        Resursi
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="table-primary">
                                <tr>
                                    <th>ID</th>
                                    <th>Naziv</th>
                                    <th>Tip</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($resursi as $resurs): ?>
                                <tr>
                                    <td><?= $resurs['ResursID'] ?></td>
                                    <td><?= $resurs['Naziv'] ?></td>
                                    <td><?= $resurs['Tip'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        Projekti
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="table-primary">
                                <tr>
                                    <th>ID</th>
                                    <th>Naziv</th>
                                    <th>Opis</th>
                                    <th>KlijentID</th>
                                    <th>TimID</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($projekti as $projekat): ?>
                                <tr>
                                    <td><?= $projekat['ProjekatID'] ?></td>
                                    <td><?= $projekat['Naziv'] ?></td>
                                    <td><?= $projekat['Opis'] ?></td>
                                    <td><?= $projekat['KlijentID'] ?></td>
                                    <td><?= $projekat['TimID'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white mt-5 py-3">
        <div class="container text-center">
            <p>&copy; 2023 Projekat</p>
        </div>
    </footer>
</body>
</html>
